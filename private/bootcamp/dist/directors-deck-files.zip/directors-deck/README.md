# The Director's Deck

Forty prompts and skill files from a company run by one person and a crew

Every card in this deck is a prompt or a skill file we use to run Modern Mustard Seed, rewritten so the nouns fit your business instead of ours. They are in the words we actually type. None of them is clever. Each one exists because the plain version of the request kept producing work we had to redo.

Words in {braces} are yours to fill. Everything else is meant to be pasted as written. Six cards are skill files: save them once as SKILL.md in a folder under ~/.claude/skills and every agent does that job the same way from then on.

Use them in order the first time through. The suits follow the life of an idea: you direct it, the crew remembers it, builds it, ships it, guards it, sells it, serves the customer who bought it, and brings you the next one.

## The cards

01. **The one-page brief** (Direct): prompts/01-direct-the-one-page-brief.md
02. **The acceptance test** (Direct): prompts/02-direct-the-acceptance-test.md
03. **The order of work** (Direct): prompts/03-direct-the-order-of-work.md
04. **The skeptic** (Direct): prompts/04-direct-the-skeptic.md
05. **The cut** (Direct): prompts/05-direct-the-cut.md
06. **Write my rules file** (Remember): prompts/06-remember-write-my-rules-file.md
07. **Save it as a memory** (Remember): prompts/07-remember-save-it-as-a-memory.md
08. **The correction** (Remember): prompts/08-remember-the-correction.md
09. **Is this a law?** (Remember): prompts/09-remember-is-this-a-law.md
10. **The handoff note** (Remember): prompts/10-remember-the-handoff-note.md
11. **Write an agent charter** (Crew): prompts/11-crew-write-an-agent-charter.md
12. **The morning briefing** (Crew, skill file): skills/morning-briefing/SKILL.md
13. **Put it on a schedule** (Crew): prompts/13-crew-put-it-on-a-schedule.md
14. **Parallel lanes** (Crew): prompts/14-crew-parallel-lanes.md
15. **Delegate it** (Crew): prompts/15-crew-delegate-it.md
16. **Build from the brief** (Build): prompts/16-build-build-from-the-brief.md
17. **The attack pass** (Build, skill file): skills/attack-pass/SKILL.md
18. **Look at it** (Build): prompts/18-build-look-at-it.md
19. **Every state** (Build): prompts/19-build-every-state.md
20. **The finish pass** (Build): prompts/20-build-the-finish-pass.md
21. **The preflight** (Ship and Guard, skill file): skills/preflight/SKILL.md
22. **Is it live?** (Ship and Guard): prompts/22-ship-and-guard-is-it-live.md
23. **Roll it back** (Ship and Guard): prompts/23-ship-and-guard-roll-it-back.md
24. **The incident note** (Ship and Guard): prompts/24-ship-and-guard-the-incident-note.md
25. **Write me a guard** (Ship and Guard): prompts/25-ship-and-guard-write-me-a-guard.md
26. **The proposal** (Sell): prompts/26-sell-the-proposal.md
27. **One person, one message** (Sell, skill file): skills/one-to-one/SKILL.md
28. **After silence** (Sell): prompts/28-sell-after-silence.md
29. **Call prep** (Sell): prompts/29-sell-call-prep.md
30. **Answer the objection** (Sell): prompts/30-sell-answer-the-objection.md
31. **The onboarding packet** (Serve): prompts/31-serve-the-onboarding-packet.md
32. **The monthly review** (Serve, skill file): skills/monthly-review/SKILL.md
33. **Reply to a review** (Serve): prompts/33-serve-reply-to-a-review.md
34. **The unhappy customer** (Serve): prompts/34-serve-the-unhappy-customer.md
35. **The handoff package** (Serve): prompts/35-serve-the-handoff-package.md
36. **The idea engine** (Ideas, skill file): skills/idea-engine/SKILL.md
37. **Kill or double down** (Ideas): prompts/37-ideas-kill-or-double-down.md
38. **Read the market** (Ideas): prompts/38-ideas-read-the-market.md
39. **What would ten times look like?** (Ideas): prompts/39-ideas-what-would-ten-times-look-like.md
40. **Sentence to shipped** (Ideas): prompts/40-ideas-sentence-to-shipped.md

## Installing the six skill files

Copy each folder inside skills/ into ~/.claude/skills/ (on Windows, C:\Users\<you>\.claude\skills\). Start a new Claude Code session and the skills load on their own.

Licensed to the ticket holder for use in their own business. Modern Mustard Seed, modernmustardseed.com.
