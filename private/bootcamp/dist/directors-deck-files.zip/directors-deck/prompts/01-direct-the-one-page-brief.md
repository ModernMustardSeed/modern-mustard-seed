# 01. The one-page brief

**Suit:** Direct
**When:** Any idea, before any building starts.

## Paste this

I want to build {the idea, in one sentence}. Before you write any code or copy, interview me. Ask one question at a time, no more than eight in total, and stop when you could explain it to a stranger. Then write a one-page brief with exactly these sections: who it is for, the problem in their words, what they do with it on the first day, what it must never do, the three things that make it excellent, what is out of scope, and how we will know it worked. Show me the brief and wait for my yes.

## Why it works

Agents build what you said, not what you meant. The interview closes the gap before it costs a rebuild.
