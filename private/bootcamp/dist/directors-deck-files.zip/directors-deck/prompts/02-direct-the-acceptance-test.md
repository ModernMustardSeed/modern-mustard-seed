# 02. The acceptance test

**Suit:** Direct
**When:** Right after the brief is approved.

## Paste this

Using the brief we just approved, write the acceptance test: a numbered list of things I can check myself, in plain words, that prove this is done. Each line must be something I can see, click, read or count. No line may say "works correctly" or "is user friendly". Include the unhappy paths: an empty state, a wrong input, a slow connection, a customer who changes their mind.

## Why it works

If you cannot check it, you cannot direct it. The test becomes the definition of done for every agent after this.
