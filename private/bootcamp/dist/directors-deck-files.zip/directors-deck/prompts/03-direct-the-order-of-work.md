# 03. The order of work

**Suit:** Direct
**When:** When the job is bigger than one sitting.

## Paste this

Break this brief into the smallest steps that each produce something I can look at. Order them so the riskiest unknown is answered first and every step leaves the project working. For each step: what gets built, what I will see when it is done, and what could block it. Nothing in step one may depend on a decision I have not made yet. List those decisions separately at the top.

## Why it works

A sequence that ends in a working thing at every step means a bad day costs one step, not the project.
