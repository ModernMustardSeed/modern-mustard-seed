# 04. The skeptic

**Suit:** Direct
**When:** Before you commit money or a week to an idea.

## Paste this

Play the most skeptical customer this idea could have. You run {their kind of business}, you have been burned by a vendor before, and you have ten seconds. Tell me the three reasons you would say no, in your own words, as bluntly as you would say them out loud. Then switch back and tell me which of the three would actually stop a sale, and what single change answers it.

## Why it works

Objections found in a prompt are free. Objections found after launch cost the launch.
