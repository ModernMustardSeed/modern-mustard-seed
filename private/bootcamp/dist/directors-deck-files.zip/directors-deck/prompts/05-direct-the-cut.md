# 05. The cut

**Suit:** Direct
**When:** When the list of features keeps growing.

## Paste this

Here is everything I want this to do: {the list}. Cut it to the version a customer would pay for on day one. For every item you cut, one line on why it can wait. For every item you keep, one line on what breaks for the customer without it. The kept list should fit in a week of building. If it does not, cut again.

## Why it works

The first version ships when someone is willing to remove things from it. Let the agent be that someone.
