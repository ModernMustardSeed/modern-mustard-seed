# 06. Write my rules file

**Suit:** Remember
**When:** The first afternoon with a crew.

## Paste this

Help me write my CLAUDE.md, the rules every agent reads before every session. Interview me one question at a time about: who I am, what the business sells and at what prices, who buys, how I write, the words I never use, the tools we use, and the mistakes that have cost me money or a customer. Then write the file. Rules are one sentence each, stated as laws, not preferences. Every law that came from a mistake names the mistake in one line underneath.

## Why it works

Everything an agent does well starts here. A rule that is not written down gets broken again.
