# 07. Save it as a memory

**Suit:** Remember
**When:** The moment you explain something for the second time.

## Paste this

Save what I just told you as a memory note. One fact per note. Give it a short name, a one-line description that would help a future session decide whether it matters, today's date, and two lines underneath: why it matters, and how to apply it. Before saving, check whether a note already covers it; update that note instead of making a second one. Link it to any related note by name.

## Why it works

The test of a crew is whether you ever have to say the same thing twice. Memory is how you pass.
