# 08. The correction

**Suit:** Remember
**When:** When a memory or a rule turns out to be wrong.

## Paste this

The note about {the subject} is wrong. The truth is {the correct fact}, as of {date}. Find every memory note, skill and rules line that repeats the wrong version, fix each one, and delete any note that is now entirely false. Do not leave the old version underneath with a correction; remove it. Then list every file you changed.

## Why it works

A wrong memory is worse than none, because the crew acts on it with confidence. Fix it everywhere at once.
