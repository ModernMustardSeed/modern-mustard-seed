# 09. Is this a law?

**Suit:** Remember
**When:** When you are tempted to add a rule.

## Paste this

I want to add this rule: {the rule}. Test it against three questions before it goes in the rules file. One: if it is broken, does a customer, a lead or a search engine see the result? Two: could an agent work it out from the files in front of it? Three: has it already been broken once, or am I stating it as a firm rule? If all three pass, write it as one sentence with the incident underneath. If not, save it as a memory note instead and tell me why.

## Why it works

Twenty laws get read. Two hundred get skimmed. The test keeps the rules file short enough to matter.
