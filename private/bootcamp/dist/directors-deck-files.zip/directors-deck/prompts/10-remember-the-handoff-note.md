# 10. The handoff note

**Suit:** Remember
**When:** At the end of any session that will be continued.

## Paste this

Write the handoff for the next session. What we set out to do, what is finished and checked, what is finished and not yet checked, what is not started, the exact file paths and branch involved, any decision waiting on me, and the first command the next session should run. Save it as a memory note named for the project. Plain facts, no summary of the conversation.

## Why it works

The next session starts cold. A good handoff makes it start where this one stopped instead of an hour earlier.
