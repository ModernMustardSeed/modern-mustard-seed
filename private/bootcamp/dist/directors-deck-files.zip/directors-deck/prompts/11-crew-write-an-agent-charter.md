# 11. Write an agent charter

**Suit:** Crew
**When:** When a job repeats often enough to deserve its own agent.

## Paste this

Write a charter for an agent whose one job is {the job}. Include: its name, the one job in one sentence, the trigger phrases that should send work to it, what it reads first, what it produces and where it saves it, what it must never do, when it must stop and ask me, and how it reports. Keep it under one page. Save it as a subagent definition in ~/.claude/agents.

## Why it works

An agent with one job and written limits is predictable. An agent with a vague job does a bit of everything, badly.
