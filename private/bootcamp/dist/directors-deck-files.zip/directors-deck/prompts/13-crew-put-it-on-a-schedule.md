# 13. Put it on a schedule

**Suit:** Crew
**When:** When a job should run without you asking.

## Paste this

Make {the job} run on its own every {schedule}. Before choosing the time, list every scheduled job that already exists and pick a minute nothing else uses. The job must write a heartbeat when it starts and when it finishes, so the morning briefing can tell a job that ran from a job that silently stopped. If it fails, it must leave a clear note saying what failed and what it needs. Show me the schedule and the heartbeat check before switching it on.

## Why it works

Jobs that start on the same minute fight, and jobs without a heartbeat fail in silence. Both rules came from a week of silence.
