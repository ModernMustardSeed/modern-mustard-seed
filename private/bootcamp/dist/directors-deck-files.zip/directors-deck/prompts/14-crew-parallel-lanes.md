# 14. Parallel lanes

**Suit:** Crew
**When:** When more than one session is working at once.

## Paste this

Before you touch this repository, check who else is working in it. List the worktrees and branches, and anything committed in the last hour. Work only in your own worktree on your own branch, created fresh from the latest main. Before every commit and every push, check again. If someone else has touched a file you are about to change, stop and tell me instead of merging over it.

## Why it works

Two sessions on one file is how a day of work disappears without a single error message.
