# 15. Delegate it

**Suit:** Crew
**When:** When a task has independent parts.

## Paste this

This task has parts that do not depend on each other: {the parts}. Send each part to its own agent with a complete brief: the goal, the files involved, what done looks like, and what it must not touch. Run them at the same time. When they report back, check each result yourself against its brief before telling me anything is finished. Give me one combined report, not their reports pasted together.

## Why it works

The director checks the work. Passing an agent's report straight to the owner is how unchecked work gets called done.
