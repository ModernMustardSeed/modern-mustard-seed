# 16. Build from the brief

**Suit:** Build
**When:** Once the brief, the test and the order are approved.

## Paste this

Build step {n} from the order of work. Use real words, real images and real data, never placeholders. Design every state: loading, empty, error and success. When you finish, check it against the acceptance test line by line and show me which lines pass, with the evidence for each: a screenshot, a test result or the output. Do not tell me it works; show me.

## Why it works

A beautiful shell with filler text is not a draft. It is the same work done twice.
