# 18. Look at it

**Suit:** Build
**When:** Any page or screen, after any visual change.

## Paste this

Take screenshots of this page at 390 pixels wide and 1440 pixels wide, and look at them before you say anything about the code. Grade them: can a stranger tell what this is and what to do within five seconds; is there one obvious next action; does anything overflow, overlap or scroll sideways on the phone; is all the text readable; is every image real and specific to us. Fix what fails, shoot again, and show me the final screenshots.

## Why it works

Agents read code. Customers look at pages. This makes the agent look.
