# 19. Every state

**Suit:** Build
**When:** Forms, checkouts, sign-ups, anything a customer fills in.

## Paste this

List every state this {form, page, flow} can be in: first visit, partly filled, wrong input in each field, submitted, failed to submit, slow connection, already submitted, came back the next day. For each state, show me what the customer sees and the exact words on screen. Every error message must say what happened and what to do next, in our voice. Then build the ones that are missing.

## Why it works

The happy path is the entry fee. Customers judge you on the error message.
