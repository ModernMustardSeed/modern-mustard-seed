# 20. The finish pass

**Suit:** Build
**When:** The last thing before it is called done.

## Paste this

Do the finish pass on {the deliverable}. The details nobody asked for: the browser tab icon, the image that shows when the link is shared, the page title, the empty-state sentence, the 404 page, the print margins, the alt text on every image, the spelling of every proper name, and every number checked against its source. List each one and whether it was already right or you fixed it.

## Why it works

Nobody notices the finish when it is there. Everybody notices when it is not.
