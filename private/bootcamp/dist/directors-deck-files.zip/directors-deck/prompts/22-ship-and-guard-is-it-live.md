# 22. Is it live?

**Suit:** Ship and Guard
**When:** Whenever anyone, including an agent, says "shipped".

## Paste this

Prove it is live. Fetch {the live URL} and find a phrase or element that exists only in the change we just made. Tell me the commit the live site is running and whether it matches ours. If the phrase is missing, do not explain it with caching; find out which version is deployed and why ours is not.

## Why it works

A green check and a deploy ID are not a ship. Shipped is a claim about the live address.
