# 23. Roll it back

**Suit:** Ship and Guard
**When:** When production is broken and customers can see it.

## Paste this

Production is broken: {what customers see}. Do not debug in production. Find the last deployment that worked, tell me which one and when, and give me the exact step to promote it. Once I confirm it is restored, revert the bad change on main so the next build does not put it back, then reproduce the problem on a branch and fix it there.

## Why it works

Restoring first and debugging second turns an outage into a blip.
