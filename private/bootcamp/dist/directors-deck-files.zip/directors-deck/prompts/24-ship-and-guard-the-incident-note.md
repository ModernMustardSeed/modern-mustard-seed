# 24. The incident note

**Suit:** Ship and Guard
**When:** After anything broke that a customer saw.

## Paste this

Write the incident note. What customers saw, from when to when. What caused it, in one paragraph a non-technical owner understands. How it was fixed. What now makes it impossible, not just less likely: a test, a check or a guard. If the answer is "be more careful", it is not finished; propose the guard. Then save the lesson as a memory note, and if it passes the law test, as a rule.

## Why it works

Every law in our rules file is an incident that got a note like this. That is how the crew gets better on its own.
