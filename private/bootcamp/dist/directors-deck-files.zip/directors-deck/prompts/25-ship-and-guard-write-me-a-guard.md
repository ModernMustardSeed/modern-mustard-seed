# 25. Write me a guard

**Suit:** Ship and Guard
**When:** When a mistake must never happen again.

## Paste this

Write a Claude Code hook that makes {the mistake} impossible. It runs before the matching tool call, reads the call as JSON, and either allows it, asks me, or blocks it with a reason Claude can act on. It must never block anything else: list five ordinary commands it must allow and five it must stop, and include a test that runs all ten. If the guard throws an error, it must allow, so a broken guard never jams the session.

## Why it works

A rule asks an agent to remember. A guard does not need it to. The dangerous things belong in guards.
