# 26. The proposal

**Suit:** Sell
**When:** After a discovery call.

## Paste this

Turn these notes into a proposal: {the notes}. First read their website and listings and note one thing that is working and one that is costing them customers. Map the work to one of our packages, and never invent or round a price. Structure: their situation in their words, what we deliver as things they could point at, what is not included, dated milestones, the price stated once, how adjustments work, and one next step. Deliver it as a designed PDF, not a printed web page.

## Why it works

A proposal that quotes the customer back to themselves reads like we already understand the business. Because we do.
