# 28. After silence

**Suit:** Sell
**When:** A prospect went quiet after a proposal or a call.

## Paste this

{Name} went quiet {how long} ago after {what happened last}. Read everything we have sent them. Write one short follow-up that adds something new: a fresh observation about their business, an answer to the question they are probably asking, or a small piece of the work done for free. No "just checking in", no "bumping this", no guilt. One ask. If this would be the third message with no reply, tell me to stop instead.

## Why it works

Silence is usually a busy week, not a no. A follow-up that brings something new respects that.
