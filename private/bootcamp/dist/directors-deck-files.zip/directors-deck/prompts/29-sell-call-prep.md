# 29. Call prep

**Suit:** Sell
**When:** An hour before any sales call.

## Paste this

I am talking to {name} at {business} in an hour. Give me one page: what the business does and how long it has been doing it, what their website and reviews say right now, what they probably want from this call, the two objections most likely to come up and a one-sentence answer to each, which of our packages fits, and the three questions that would move this to a yes. Facts only, each with where you found it.

## Why it works

Ten minutes of reading turns a discovery call into a second meeting.
