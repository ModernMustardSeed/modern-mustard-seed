# 30. Answer the objection

**Suit:** Sell
**When:** When a prospect pushes back.

## Paste this

A prospect said: "{the objection, in their words}". Tell me what they are actually worried about underneath it. Then write my answer in two or three sentences: acknowledge it plainly, give one specific fact or result that addresses it, and end with a question that moves forward. No pressure, no discount, no defensiveness.

## Why it works

Most objections are a question in disguise. Answering the question wins more than arguing with the objection.
