# 31. The onboarding packet

**Suit:** Serve
**When:** The day a customer says yes.

## Paste this

{Customer} just bought {package}. Write the onboarding packet: a welcome email under 150 words with the kickoff date and exactly what we need by when; no more than ten intake questions tailored to their business, none of which their website already answers; an access checklist of every login we need with how to grant it without sending a password; the scope confirmation word for word from the proposal; and the dated milestones. They get their own accounts in their own name.

## Why it works

The week after yes decides whether they trust you for the next year.
