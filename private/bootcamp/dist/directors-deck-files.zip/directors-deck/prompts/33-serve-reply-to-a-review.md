# 33. Reply to a review

**Suit:** Serve
**When:** Every new review, good or bad.

## Paste this

Draft a reply to this review: "{the review}". Speak as the business: we, us, our. For a good review: thank them by name, mention one specific thing they said, two sentences at most. For a bad one: thank them once, own what is ours without explaining our internal process, say what we did or will do, and offer a direct line. Never argue, never reveal private details. Show me the draft; do not post it.

## Why it works

Future customers read the replies more closely than the reviews.
