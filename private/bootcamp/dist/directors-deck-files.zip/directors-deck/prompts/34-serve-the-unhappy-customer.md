# 34. The unhappy customer

**Suit:** Serve
**When:** A complaint arrives.

## Paste this

A customer wrote: "{the complaint}". Read their history with us first. Draft a reply that apologizes once, in the body, never the subject line; states what we will do and by when, specifically; and does not explain our internal mistakes. Under 120 words. Then list what actually needs fixing on our side and whether it could happen to another customer.

## Why it works

One apology and a dated fix beats three paragraphs of explanation every time.
