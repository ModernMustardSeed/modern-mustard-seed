# 35. The handoff package

**Suit:** Serve
**When:** When a customer should be able to run it without you.

## Paste this

Prepare the handoff for {customer}. List every account, service and key involved, who owns each today, and the steps to move each into their name. Write a one-page runbook in plain words: what runs, when, what to do if it stops, and who to call. List every secret that must be rotated after the transfer. Then write the walkthrough script for a thirty-minute call where they do each step themselves while we watch.

## Why it works

We build things customers own and can run without us. The handoff is where that stops being a slogan.
