# 37. Kill or double down

**Suit:** Ideas
**When:** When a product, offer or channel has been running a while.

## Paste this

Look at {the product, offer or channel} honestly. What did we expect when we started, and what actually happened, in numbers with sources? What does it cost us each month in money and in attention? Make the case to kill it, then the case to double down, each as strongly as you can. Then recommend one, and name the number that would change your mind by a date you choose.

## Why it works

Most small businesses carry three things that should have been stopped a year ago. Ask the question on a schedule.
