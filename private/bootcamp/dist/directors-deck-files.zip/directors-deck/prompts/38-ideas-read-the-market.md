# 38. Read the market

**Suit:** Ideas
**When:** Before a new offer or a price change.

## Paste this

Research the market for {offer} in {place or audience}. Find the five businesses customers most often compare us to. For each: what they sell, at what price where it is public, what their customers praise, what they complain about, and their strongest claim. Then tell me where there is a gap we could own, and the one sentence that would make it obvious to a customer. Cite every fact.

## Why it works

You cannot be different from competitors you have not read.
