# 39. What would ten times look like?

**Suit:** Ideas
**When:** Once a quarter.

## Paste this

Our business today does {current size: customers, revenue, jobs a week}. Describe what the same business looks like at ten times that, with the same headcount and a crew of agents. Which jobs become agents first, in what order? What breaks at three times, and what has to be true before then? What would I stop doing personally? End with the three moves for this quarter.

## Why it works

The question is not whether to grow. It is which work stops needing you, in which order.
