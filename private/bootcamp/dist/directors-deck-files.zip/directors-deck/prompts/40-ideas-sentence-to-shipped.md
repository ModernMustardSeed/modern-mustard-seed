# 40. Sentence to shipped

**Suit:** Ideas
**When:** Build Week: one idea, Monday to Friday.

## Paste this

This week we ship {the idea} from a sentence to something a real customer can use by Friday. Monday: the brief, the acceptance test and the cut, all approved by noon. Tuesday and Wednesday: build in steps that each leave it working, attack pass at the end of each day. Thursday: every state, the finish pass, a real person tries it. Friday: preflight, ship, prove it is live, and put it in front of five customers. Tell me each morning where we are against this plan.

## Why it works

A week with a fixed end is the fastest way we know to learn whether an idea is worth more weeks.
