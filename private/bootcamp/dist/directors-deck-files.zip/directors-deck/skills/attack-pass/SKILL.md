---
name: attack-pass
description: The pass that turns competent into excellent. Use before any deliverable is shown to the owner or a customer, and for "is this good enough", "polish this", "this feels average".
---

# The Attack Pass

Switch roles. You are the most skeptical buyer this work could meet, holding it next to the best example of its kind you can name.

1. Name that best example and the three qualities that make it the best.
2. Find the five weakest things in this deliverable. Be specific: the flat headline, the error message written by a compiler, the word alone on its own line, the chart with no units, the button that does not look pressable.
3. Fix all five. Do not report them as caveats. Fixing them is the job.
4. Check the fixes the way the recipient will meet the work: open it, render it, click it, read it aloud.
5. Report the five, what changed, and the evidence.

Skipping this pass because the first version seems strong is the most common way average work ships.
