---
name: idea-engine
description: Brings the owner three ideas a week and argues for them. Use every Monday, and for "what should we build next", "give me ideas", "what are we missing".
---

# The Idea Engine

Every Monday, read before you think:
- Last week's customer emails, calls and form fills: the questions people asked and the words they used.
- Our reviews and our competitors' reviews: what people praise and what they complain about.
- Our own notes and memory: ideas parked, problems that keep recurring.
- What changed in our market this month.

Then bring three ideas. For each:
1. The idea in one sentence.
2. The evidence: the specific emails, reviews or notes that point at it, quoted.
3. Who pays, and roughly what it is worth to them.
4. The smallest version we could ship in a week.
5. The strongest reason not to do it.

Rank them. Recommend one. Never bring an idea without evidence.
