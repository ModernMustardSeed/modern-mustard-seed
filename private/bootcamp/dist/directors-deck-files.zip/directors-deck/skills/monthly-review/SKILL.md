---
name: monthly-review
description: The monthly sweep of every live customer: real numbers, a one-page report and an email each, held for the owner's review. Use for "monthly reports", "month-end sweep".
---

# The Monthly Review

Read only during the sweep. Change nothing.

## For each live customer
1. What we shipped this month, in plain words.
2. What it changed: the numbers that matter to their business, each with its source and date range. Never estimate a number that was not measured.
3. What broke and what we fixed, only what they noticed or would want to know.
4. The one thing we recommend for next month, and why.

## The report
One page: their name, the month, the four sections. A chart only when a trend matters.

## The email
Under 150 words. The headline result first, the report attached, one next step.

## The gate
Every report and email waits for the owner. Only approved ones are sent.
