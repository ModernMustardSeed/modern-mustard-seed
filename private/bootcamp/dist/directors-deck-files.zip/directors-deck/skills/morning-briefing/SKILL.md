---
name: morning-briefing
description: The owner's daily briefing: what ran overnight, what shipped, what failed, what waits on a decision, and the three things worth doing today. Use for "brief me", "what is going on", "what should I do today".
---

# The Morning Briefing

Read, do not guess. Every line has a source.

## Gather
1. Overnight: every scheduled job, whether it ran, whether it finished. A job that did not report is a failure until proven otherwise.
2. Shipped: merged changes since yesterday, each checked on the live address.
3. Inbox: customer emails, form fills, missed calls and voicemails that need a person.
4. Money: payments received, payments failed, refunds, anything unusual.
5. Decisions waiting: anything an agent stopped to ask about, and for how long.

## Write, one screen, in this order
1. Three decisions for today, each with options and a recommendation.
2. What broke, and what was done or is needed.
3. What shipped, one line each, with the live link.
4. The numbers, against the same day last week.
5. Three things worth doing today, in order.

If nothing broke, say "Nothing broke" in one line and move on.
