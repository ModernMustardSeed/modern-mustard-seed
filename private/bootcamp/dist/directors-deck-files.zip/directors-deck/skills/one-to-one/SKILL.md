---
name: one-to-one
description: Writes one-to-one outreach to a named person. Use for any cold or warm email, LinkedIn note or message to a prospect. Never writes a template meant for a list.
---

# One Person, One Message

If it could be sent to anyone else unchanged, it does not go.

## Research first
- The person's name and role, from their own site or profile.
- One specific, checkable fact about their business, read on the live source today.
- Whether they have heard from us before.

Never tell someone their site lacks something unless you read the live page and it truly is not there. Never print a guessed number about their business.

## The message, under 120 words
1. The observation: one sentence about them, specific enough that they know a person looked.
2. The outcome: one sentence on what changes for them.
3. The proof: one line, a real result or a real link.
4. The ask: one small step that costs them nothing.

## Follow-ups
Two at most, at four and nine days, each adding something new. Any reply ends the sequence. The owner approves every first message.
