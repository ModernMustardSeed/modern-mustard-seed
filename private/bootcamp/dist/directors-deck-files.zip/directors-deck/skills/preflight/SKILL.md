---
name: preflight
description: The checks that run before any change leaves this machine. Use before every commit, push, merge or deploy, and for "ship it", "push this", "is this ready".
---

# The Preflight

In order. Stop at the first failure, fix the cause, and start again from that step. Never switch a check off to get past it.

1. Fetch the latest main and rebase onto it. A stale base makes every other check meaningless.
2. Type check.
3. Lint.
4. Build. A local build that passes is the only real predictor of the host's build passing.
5. Secrets: no .env file appears in the list of changed files.
6. Commit with a message that says what changed and why.
7. Push and open the pull request. Merge when the checks are green.
8. Open the live address and find something that exists only in the new version. Until then, the word is "merged", not "live".
